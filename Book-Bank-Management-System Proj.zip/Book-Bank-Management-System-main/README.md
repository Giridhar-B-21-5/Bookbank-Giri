## E-Book Bank
<p>This is a mini-project of an E-Book Bank. It contains text-books suggested in the syllabus(<i>R-2017</i>) of <i>Anna University</i>.</p><br/>

> Software Requirements

  - [X] <a href="https://www.apachefriends.org/download.html">XAMPP [Web Server]</a><br/>
  - [x] <a href="https://atom.io/">Atom [Editor]</a><br/><br/>


> How to run the project ?

1. Install XAMPP.<br/>
2. Open XAMPP control panel and <i>start</i> the services <i>Apache, MySQL</i>.<br/>
3. Download the code/ Clone the repository in your system.<i> Make sure you save them in a single folder.</i><br/>
4. Open your web browser and type <i>localhost/Module 1/index.php</i> in the search bar.

